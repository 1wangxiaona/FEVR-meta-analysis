library("meta")
data <- read.csv("C:/Users/Desktop/data.csv")
data
rate <- transform(data,p=Case/Sample.size)
shapiro.test(rate$p)
rate <- transform(data,log=log(Case/Sample.size))
shapiro.test(rate$log)
rate <- transform(data,logit=log((Case/Sample.size)/(1-Case/Sample.size)))
shapiro.test(rate$logit)
rate <- transform(data,arcsin.size=asin(sqrt(Case/(Sample.size+1))))
shapiro.test(rate$arcsin)
rate <- transform(data,darcsin=0.5*(asin(sqrt(Case/(Sample.size+1)))+asin((sqrt(Case+1)/(Sample.size+1)))))
shapiro.test(rate$darcsin)
meta1 <- metaprop(Case,Sample.size,data=data,studlab = paste(data$Author,data$Year,sep="-"),sm="PRAW",incr=0.5,allincr=TRUE,addincr=FALSE)
meta1
jpeg("Forest plot.jpeg",height = 1300,width = 800)
forest(meta1,digits=3,family="sans",fontsize=9.5,lwd=2,col.diamond.fixed="lightslategray",col.diamond.lines.fixed="lightslategray",
       col.diamond.random="maroon",col.diamond.lines.random="maroon",col.square="skyblue",col.study="lightslategray",
       lty.fixed=4,plotwidth="8cm",colgap.forest.left="1cm",colgap.forest.right="1cm",just.forest="right",colgap.left="0.5cm",
       colgap.right="0.5cm")
dev.off()
funnel(meta1)
metabias(meta1,method="linreg")
metabias(meta1,method="linreg",plotit = TRUE,k.min=10)
jpeg("Sensitivity analysis results.jpeg",height = 1300,width = 800)
forest(metainf(meta1,pooled = "random"),comb.random=TRUE,family="sans",fontsize=9.5,lwd=2,col.diamond.fixed="lightslategray",col.diamond.lines.fixed="lightslategray",
       col.diamond.random="maroon",col.diamond.lines.random="maroon",col.square="skyblue",col.study="lightslategray",
       lty.fixed=4,plotwidth="8cm",colgap.forest.left="1cm",colgap.forest.right="1cm",just.forest="right",colgap.left="0.5cm",
       colgap.right="0.5cm")
dev.off()
tf1 <- trimfill(meta1,comb.random = TRUE)
summary(tf1)
funnel(tf1)
meta2 <- metamean(n,mean,sd,data=data,studlab = paste(data$Author,data$Year,sep="-"))
meta2
forest(meta2,digits=2,family="sans",fontsize=9.5,lwd=2,col.diamond.fixed="lightslategray",col.diamond.lines.fixed="lightslategray",
       col.diamond.random="maroon",col.diamond.lines.random="maroon",col.square="skyblue",col.study="lightslategray",
       lty.fixed=4,plotwidth="8cm",colgap.forest.left="1cm",colgap.forest.right="1cm",just.forest="right",colgap.left="0.5cm",
       colgap.right="0.5cm")
